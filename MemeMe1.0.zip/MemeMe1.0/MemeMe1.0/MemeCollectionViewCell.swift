//
//  MemeCollectionViewCell.swift
//  MemeMe1.0
//
//  Created by هَديل  on 23/04/1440 AH.
//  Copyright © 1440 Hadeel. All rights reserved.
//

import UIKit

class MemeCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var top: UILabel!
    @IBOutlet weak var bottom: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    
}
