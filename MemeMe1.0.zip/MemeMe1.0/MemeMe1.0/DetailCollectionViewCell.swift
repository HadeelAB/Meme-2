//
//  DetailCollectionViewCell.swift
//  MemeMe1.0
//
//  Created by هَديل  on 26/04/1440 AH.
//  Copyright © 1440 Hadeel. All rights reserved.
//

import UIKit

class DetailCollectionViewCell: UICollectionViewCell {
    
}
