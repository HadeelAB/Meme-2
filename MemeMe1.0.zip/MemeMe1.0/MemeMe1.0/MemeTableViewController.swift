//
//  MemeTableViewController.swift
//  MemeMe1.0
//
//  Created by هَديل  on 23/04/1440 AH.
//  Copyright © 1440 Hadeel. All rights reserved.
//

import UIKit

class MemeTableViewController: UITableViewController{

    @IBOutlet var tableVeiw: UITableView!
    @IBAction func newMeme(_ sender: Any) {
        let newMeme = self.storyboard!.instantiateViewController(withIdentifier: "MemeMaker")
        navigationController!.pushViewController(newMeme, animated: true)
    }
    
    var memes: [Meme]! {
        let object = UIApplication.shared.delegate
        let appDelegate = object as! AppDelegate
        return appDelegate.memes
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        tableVeiw.reloadData()
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.memes.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell")!
        let memeMakerForRow = self.memes[(indexPath as NSIndexPath).row]
        cell.imageView?.image = memeMakerForRow.memedImage
        cell.textLabel?.text = memeMakerForRow.topText + memeMakerForRow.bottomText

        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let meme = memes[indexPath.row]
        let memeController = self.storyboard!.instantiateViewController(withIdentifier: "DetailViewController") as! DetailViewController
        
        memeController.selectedImage!.image = meme.memedImage
        navigationController!.pushViewController(memeController, animated: true)
    }
}
