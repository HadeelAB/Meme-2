//
//  Meme.swift
//  pickImage
//
//  Created by هَديل  on 19/04/1440 AH.
//  Copyright © 1440 Hadeel. All rights reserved.
//

import Foundation
import UIKit

struct Meme {
    let topText: String
    let bottomText: String
    let originalImage: UIImage
    let memedImage: UIImage
    
    static var memes: [Meme]! {
        let object = UIApplication.shared.delegate
        let appDelegate = object as! AppDelegate
        return appDelegate.memes
    }
}
